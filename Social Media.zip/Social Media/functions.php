<?php
 
 ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 if(isset($_POST["Import"])){

		$caption =  $_POST['caption'];
		 $filename=$_FILES["photo"]["name"];
		$file_name_array = explode(".", basename($_FILES["photo"]["name"]));
		$csv_file_path = pathinfo($filename, PATHINFO_EXTENSION);
 	  $filepath= "data/"."upload_image_".date('d-m-Y_h_i_s').".".$csv_file_path;

 	if(move_uploaded_file($_FILES["photo"]["tmp_name"],$filepath)){
 		
         $sqlconn = mysqli_connect("localhost", "root","");
            mysqli_select_db($sqlconn,'photos');
	           $sql = "INSERT into path (caption,img_path)values('$caption','$filepath') ";
                   $result = mysqli_query($sqlconn,$sql)or die(mysqli_error($sqlconn));
				if($result)
				{
					echo "<script type=\"text/javascript\">
							alert(\"Upload successfully\");
							window.location = \"Index.php\"
						  </script>";		
				}
				else {
					echo "<script type=\"text/javascript\">
							alert(\"Upload successfully and query error\");
							window.location = \"Index.php\"
						  </script>";
				}
	       
 	}else{
 	 echo "<script type=\"text/javascript\">
						alert(\"File has been failed.\");
				window.location = \"Index.php\"
					</script>";
 	}


           
        }


	

		 
 
 
 ?>