<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <title>Social Media</title>
        <style type="text/css">
            table
            {

    padding: 10px;
    border-right: 2px solid black;
     border-left: 2px solid black;
     width: 100%;
            }
        </style>
    </head>
    <body style="text-align:center;">
                <div class="row">
                    <div class="col-12"><h1 class="welcome">Photo Galary</h1></div>
                    <br><br><br>
                    
                    <div style="width: 50%;text-align: center; margin-left: 25%;height: auto; padding: 20px;"> 

                <form class="form-horizontal" action="functions.php" method="post" name="upload_photo" enctype="multipart/form-data">
                    
                        
                                <input type="file" name="photo" id="photo" class="input-large" style="margin: 10px"><br>
                                <input type="text" name="caption" id="caption" style="width: 100%;height: 100px;font-size: 30px; border: none;" placeholder="Write Something"><br><br>

                                <button type="submit" id="submit" name="Import" class="btn btn-primary button-loading" data-loading-text="Loading...">Upload</button>
                            </form>
                            <?php 
                            $sqlconn = mysqli_connect("localhost", "root","");
            mysqli_select_db($sqlconn,'photos');

            $query="SELECT * FROM `path`";
            $result=mysqli_query($sqlconn,$query); 
            echo "<table '>
                <tr>
                </tr>";
            while($row = mysqli_fetch_array($result))
            {
             
              ?>
               
                
               <tr><h3 style="text-align: left"><?php echo $row['caption']; ?></h3></tr>
                 <tr><img src="<?php echo $row['img_path'];?>" width="100%" height="50%"></tr>
        
               
                <?php
            }
            ?>
               </table>
                            
                        </div>
 
                
            </body>
</html>
